test_that("sumSqrtScore works", {
  expect_equal(round(sumSqrtScore(rep(0,10)),1) , 22.5)
})
